# TM - The Messenger
Messaging system between friends

# Introduction
 - Brief introduction to the system.

# Requirements
 - Tests performed on Windows 10 with python (3.8.1)

## libraries
 - Django==3.0.3
 - python-decouple==3.3